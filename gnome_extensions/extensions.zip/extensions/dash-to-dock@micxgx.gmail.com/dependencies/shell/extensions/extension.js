export * as Extension from 'resource:///org/gnome/shell/extensions/extension.js';
